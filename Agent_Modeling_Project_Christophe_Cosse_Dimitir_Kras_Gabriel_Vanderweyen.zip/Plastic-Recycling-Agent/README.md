# Plastic-Recycling-Agent
A agent based model that simulates the collection and recycling of plastic waste in the city of Delft
